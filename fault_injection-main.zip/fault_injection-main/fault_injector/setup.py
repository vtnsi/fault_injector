from setuptools import setup, find_packages

setup(
    name="fault_injector",
    version="1.0",
    packages=find_packages(),
)